import mysql.connector
from mysql.connector import Error

def create_connection():
    connection = None
    try:
        connection = mysql.connector.connect(
            host='localhost',
            database='spending_tracker',
            user='your_username',
            password='your_password'
        )
        if connection.is_connected():
            print('Connected to MySQL database')
            return connection
    except Error as e:
        print(f'Error connecting to MySQL database: {e}')

    return connection

def create_expenses_table(connection):
    query = """
    CREATE TABLE IF NOT EXISTS expenses (
        id INT AUTO_INCREMENT PRIMARY KEY,
        date DATE NOT NULL,
        category VARCHAR(255) NOT NULL,
        description VARCHAR(255) NOT NULL,
        amount FLOAT NOT NULL
    )
    """
    try:
        cursor = connection.cursor()
        cursor.execute(query)
        connection.commit()
        print('Expenses table created')
    except Error as e:
        print(f'Error creating expenses table: {e}')

def insert_expense(connection, expense):
    query = """
    INSERT INTO expenses (date, category, description, amount)
    VALUES (%s, %s, %s, %s)
    """
    try:
        cursor = connection.cursor()
        cursor.execute(query, expense)
        connection.commit()
        print('Expense inserted successfully')
    except Error as e:
        print(f'Error inserting expense: {e}')

def get_expenses(connection):
    query = "SELECT * FROM expenses"
    try:
        cursor = connection.cursor()
        cursor.execute(query)
        expenses = cursor.fetchall()
        return expenses
    except Error as e:
        print(f'Error retrieving expenses: {e}')

def get_income(connection):
    query = "SELECT income FROM users"
    try:
        cursor = connection.cursor()
        cursor.execute(query)
        income = cursor.fetchall()
        return income
    except Error as e:
        print(f'Error retrieving income: {e}')

def update_income(income):
    sql = '''UPDATE users SET income = ?'''
    params = (income,)
    execute_query(sql, params)
    
def create_users_table(connection):
    query = """
    CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        income FLOAT NOT NULL,
        username VARCHAR(255) NOT NULL,
        password VARCHAR(255) NOT NULL
    )
    """
    try:
        cursor = connection.cursor()
        cursor.execute(query)
        connection.commit()
        print('Users table created')
    except Error as e:
        print(f'Error creating users table: {e}')

def insert_user(connection, username, password):
    query = """
    INSERT INTO users (name,income,username, password)
    VALUES (%s, %s)
    """
    try:
        cursor = connection.cursor()
        cursor.execute(query, (username, password))
        connection.commit()
        print('User inserted successfully')
    except Error as e:
        print(f'Error inserting user: {e}')


def close_connection(connection):
    if connection.is_connected():
        connection.close()
        print('Connection to MySQL database closed')
