import sys

from kivy.metrics import dp
from kivy.app import App
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.lang import Builder
from kivy.uix.image import Image
from kivy.core.window import Window
from kivy.config import Config
from kivy.uix.popup import Popup
import matplotlib.pyplot as plt
from kivy.garden.matplotlib.backend_kivyagg import FigureCanvasKivyAgg
sys.path.append('BMdata')
from database import get_expenses,create_connection,close_connection



Builder.load_string('''
<StatisticsScreen>:
    BoxLayout:
        orientation: 'vertical'
        padding: dp(10)
        spacing: dp(10)
        canvas.before:
            Color:
                rgba: (221/255, 1, 187/255, 1)
            Rectangle:
                pos: self.pos
                size: self.size

        Label:
            text: 'Statistics'
            font_size: '20sp'

        BoxLayout:
            id: pie_chart_layout
            size_hint_y: None
            height: dp(300)

        BoxLayout:
            orientation: 'horizontal'
            size_hint_y: None
            height: dp(30)

            Label:
                text: 'Total Expenses: '
                size_hint_x: 0.3

            Label:
                id: total_expenses_label
                text: '0'
                size_hint_x: 0.7
                text_size: self.size
                halign: 'left'

        BoxLayout:
            orientation: 'horizontal'
            size_hint_y: None
            height: dp(30)

            Label:
                text: 'Average Expense: '
                size_hint_x: 0.3

            Label:
                id: average_expense_label
                text: '0'
                size_hint_x: 0.7
                text_size: self.size
                halign: 'left'

        BoxLayout:
            orientation: 'horizontal'
            size_hint_y: None
            height: dp(30)

            Label:
                text: 'Maximum Expense: '
                size_hint_x: 0.3

            Label:
                id: maximum_expense_label
                text: '0'
                size_hint_x: 0.7
                text_size: self.size

        BoxLayout:
            orientation: 'horizontal'
            size_hint_y: None
            height: dp(30)

            Label:
                text: 'Minimum Expense: '
                size_hint_x: 0.3

            Label:
                id: minimum_expense_label
                text: '0'
                size_hint_x: 0.7
                text_size: self.size
                halign: 'left'

        BoxLayout:
            size_hint: 1, None
            height: dp(50)
            spacing: dp(22)
            Button:
                size_hint: None,None
                size: dp(50), dp(50)
                background_normal:'../BMassets/exit.png'
                on_release: root.manager.current = 'menu_screen'
            Button:
                size_hint: None,None
                size: dp(50), dp(50)
                background_normal:'../BMassets/logout.png'
                on_release: root.manager.current = 'login_screen'
            Button:
                size_hint: None,None
                size: dp(50), dp(50)
                background_normal:'../BMassets/home.png'
                on_release: root.manager.current = 'home_screen'
            Button:
                size_hint: None,None
                size: dp(50), dp(50)
                background_normal:'../BMassets/expenses.png'
                on_release: root.manager.current = 'add_expense_screen'
            Button:
                size_hint: None,None
                size: dp(50), dp(50)
                background_normal:'../BMassets/statistics.png'
                on_release: root.show_popup()
''')



class StatisticsScreen(Screen):
    def on_pre_enter(self):
        # Update the statistics labels with the calculated values
        self.update_statistics_labels()
        self.draw_pie_chart()

    def update_statistics_labels(self):
        total_expenses = self.calculate_total_expenses()
        average_expense = self.calculate_average_expense()
        maximum_expense = self.calculate_maximum_expense()
        minimum_expense = self.calculate_minimum_expense()

        self.ids.total_expenses_label.text = str(total_expenses)+'$'
        self.ids.average_expense_label.text = str(average_expense)+'$'
        self.ids.maximum_expense_label.text = str(maximum_expense)+'$'
        self.ids.minimum_expense_label.text = str(minimum_expense)+'$'

    def calculate_total_expenses(self):
        
        return 1000

    def calculate_average_expense(self):
        
        return 250

    def calculate_maximum_expense(self):
        
        return 500

    def calculate_minimum_expense(self):
        
        return 100
    
    def show_popup(self):
        popup_content = Label(text='You are already on Home Screen')
        popup = Popup(title='Warning', content=popup_content, size_hint=(None, None), size=(250, 100))
        popup.open()

    def draw_pie_chart(self):
        conn=create_connection()
        if conn is not None:
            expenses = get_expenses()

            # Create a dictionary to store the category and total expense
            category_expenses = {}

            # Calculate the total expense for each category
            for expense in expenses:
                category = expense['category']
                amount = expense['amount']

                if category in category_expenses:
                    category_expenses[category] += amount
                else:
                    category_expenses[category] = amount

            # Create a figure and axis for the pie chart
            fig, ax = plt.subplots()

            # Get the category labels and expenses
            labels = list(category_expenses.keys())
            expenses = list(category_expenses.values())

            # Draw the pie chart
            ax.pie(expenses, labels=labels, autopct='%1.1f%%')

            # Create a FigureCanvasKivyAgg widget to display the pie chart in Kivy
            pie_chart_widget = FigureCanvasKivyAgg(figure=fig)
            self.ids.pie_chart_layout.add_widget(pie_chart_widget)
            close_connection(conn)