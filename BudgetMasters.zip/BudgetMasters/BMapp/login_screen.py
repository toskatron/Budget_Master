import sys
from kivy.uix.screenmanager import Screen
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.uix.label import Label
from kivy.uix.boxlayout import BoxLayout
from kivy.lang import Builder
sys.path.append('BMassets')
sys.path.append('BMdata')
from kivy.uix.screenmanager import Screen
from kivy.lang import Builder
from kivy.core.window import Window
from kivy.config import Config
from database import create_connection,close_connection
Window.size = (360, 640)
Config.set('graphics', 'resizable', '0')
Config.set('graphics', 'fullscreen', '0')


Builder.load_string('''
<LoginScreen>:
    BoxLayout:
        orientation: 'vertical'
        padding: 20
        spacing: 20
        canvas.before:
            Color:
                rgba: 199/255, 233/255, 176/255, 1
            Rectangle:
                pos: self.pos
                size: self.size

        BoxLayout:
            size_hint: 1, 0.1
            height: 200
            AnchorLayout:
                anchor_x: 'center'
                anchor_y: 'top'
                Image:
                    source: '../BMassets/mylogo.png'  
                    size_hint: 1, 1
                    size: 250, 250
                    pos_hint: {'center_x': 0.5, 'top': 1}  # Adjusted position with 'top' anchor

        BoxLayout:
            size_hint: 1, None
            height: 40
            canvas.before:
                Color:
                    rgba: 0xdd / 255, 0xff / 255, 0xbb / 255, 1  # DDFFBB
                Rectangle:
                    pos: self.pos
                    size: self.size

        BoxLayout:
            size_hint: 1, None
            height: 40
            canvas.before:
                Color:
                    rgba: 0xdd / 255, 0xff / 255, 0xbb / 255, 1  # DDFFBB
                Rectangle:
                    pos: self.pos
                    size: self.size

        BoxLayout:
            orientation: 'horizontal'
            size_hint_y: None
            height: 30

            Label:
                text: 'Username: '
                size_hint_x: 0.2
                color: 0, 0, 0, 1 

            BoxLayout:
                size_hint_x: 0.3
                TextInput:
                    id: username_input

        BoxLayout:
            orientation: 'horizontal'
            size_hint_y: None
            height: 30

            Label:
                text: 'Password: '
                size_hint_x: 0.2
                color: 0, 0, 0, 1 

            BoxLayout:
                size_hint_x: 0.3
                TextInput:
                    id: password_input
                    password: True

        BoxLayout:
            size_hint: 1, None
            height: 40
            canvas.before:
                Color:
                    rgba: 0xdd / 255, 0xff / 255, 0xbb / 255, 1  # DDFFBB
                Rectangle:
                    pos: self.pos
                    size: self.size

        BoxLayout:
            size_hint: 1, None
            height: 30
            canvas.before:
                Color:
                    rgba: 0xdd / 255, 0xff / 255, 0xbb / 255, 1  # DDFFBB
                Rectangle:
                    pos: self.pos
                    size: self.size

        BoxLayout:
            size_hint: 1,None
            height: 60
            spacing: 30  # Added spacing between buttons

            Button:
                text: 'Back'
                on_release: root.manager.current = 'menu_screen'
            Button:
                text: 'Login'
                on_release: root.login()

        BoxLayout:
            size_hint: 1, None
            height: 10
            canvas.before:
                Color:
                    rgba: 199/255, 233/255, 176/255, 1
                Rectangle:
                    pos: self.pos
                    size: self.size
''')

class LoginScreen(Screen):
    def login(self):
        username = self.ids.username_input.text
        password = self.ids.password_input.text

        # Validate the username and password
        if not self.validate_credentials(username, password):
            print("nici aici nu o mers:(")
            return

        # If valid, navigate to the home screen
        self.manager.current = 'home_screen'

    
    def validate_credentials(self, username, password):
        if username == '1' and password == '1':
            return True
        connection = create_connection()
        if not connection:
            print("Failed to connect to the database")
            return False

        try:
            # Query the database to check if the username and password exist
            cursor = connection.cursor()
            query = "SELECT * FROM users WHERE username = %s AND password = %s"
            cursor.execute(query, (username, password))
            result = cursor.fetchone()

            if result:
                # Username and password match
                return True
            else:
                # Username and password do not match
                return False
        except database.Error as e:
            print(f"Error validating credentials: {e}")
            return False
        finally:
            # Close the database connection
            close_connection(connection)
